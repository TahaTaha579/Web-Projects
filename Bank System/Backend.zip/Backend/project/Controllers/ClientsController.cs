﻿using System.Data;
using BusinessLayer;
using Microsoft.AspNetCore.Mvc;

namespace project.Controllers;

[Route("api/[controller]")]
[ApiController]
public class ClientsController : ControllerBase
{
    [HttpGet("GetTotalClients")]
    public IActionResult GetTotalClients()
    {
        var total = ClientsBusinessLayer.GetTotalClients();

        return Ok(new { Total = total });
    }

    [HttpGet("GetClients")]
    public IActionResult GetClients()
    {
        // _logger.LogInformation("Get All Genres");
        var clients = ClientsBusinessLayer.GetAllClients();
        var target = clients.AsEnumerable()
            .Select(row => new
            {
                ClientId = row.Field<int>(0),
                PinCode = row.Field<string>(1)!,
                FirstName = row.Field<string>(2)!,
                LastName = row.Field<string>(3)!,
                Balance = row.Field<decimal>(4),
                Email = row.Field<string>(5)!,
                Phone = row.Field<string>(6)!,
                DateOfBirth = row.Field<DateTime>(7).ToShortDateString(),
            }).ToList();
        return Ok(target);
    }

    [HttpGet("GetClientById/{ID}")]
    public IActionResult GetClientById(byte id)
    {
        if (id == 0)
        {
            // return StatusCode(StatusCodes.Status400BadRequest);
            // return BadRequest();

            ModelState.AddModelError("Error", "InValid");
            return BadRequest(ModelState);
        }

        var client = ClientsBusinessLayer.FindClient(id);

        if (client == null)
            return NotFound();

        return Ok(client);
    }

    [HttpPost("AddClient")]
    public IActionResult AddClient([FromBody] ClientsBusinessLayer clientInfo)
    {
        return Ok(new { IsSaved = clientInfo.Save() });
    }

    [HttpPut("UpdateClient")]
    public IActionResult UpdateClient([FromBody] ClientsBusinessLayer clientInfo)
    {
        return Ok(new { IsSaved = clientInfo.Save() });
    }

    [HttpDelete("DeleteClient/{id}")]
    public IActionResult DeleteAsync(byte id)
    {
        if (id == 0)
            return BadRequest();

        var client = ClientsBusinessLayer.FindClient(id);

        if (client == null)
            return NotFound();

        client.Delete();

        return Ok();
    }

    [HttpPost("Deposit/{id}")]
    public IActionResult Deposit(int id, [FromBody] decimal amount)
    {
        if (id <= 0 || amount < 0)
            return BadRequest();

        var client = ClientsBusinessLayer.FindClient(id);

        if (client == null)
            return NotFound();

        return Ok(new { IsUpdated = client.Deposit(amount) });
    }

    [HttpPost("Withdraw/{id}")]
    public IActionResult Withdraw(int id, [FromBody] decimal amount)
    {
        if (id <= 0 || amount < 0)
            return BadRequest();

        var client = ClientsBusinessLayer.FindClient(id);

        if (client == null)
            return NotFound();

        return Ok(new { IsUpdated = client.Withdraw(amount) });
    }

    [HttpPost("Transfer/{fromClientId}/{toClientId}")]
    public IActionResult Transfer(int fromClientId, int toClientId, [FromBody] decimal amount)
    {
        if (amount < 0)
            return BadRequest();

        var fromClient = ClientsBusinessLayer.FindClient(fromClientId);
        var toClient = ClientsBusinessLayer.FindClient(toClientId);

        if (fromClient == null || toClient == null)
            return NotFound();

        return Ok(new { IsUpdated = fromClient.Transfer(amount, toClient, 2) });
    }
}