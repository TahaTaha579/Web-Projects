﻿using System.Data;
using BusinessLayer;
using Microsoft.AspNetCore.Mvc;

namespace project.Controllers;

[Route("api/[controller]")]
[ApiController]
public class CurrenciesController : ControllerBase
{
    [HttpGet("GetTotalCurrencies")]
    public IActionResult GetTotalCurrencies()
    {
        var total = CurrenciesBusinessLayer.GetTotalCurrencies();

        return Ok(new { Total = total });
    }


    [HttpGet("GetCurrencies")]
    public IActionResult GetCurrencies()
    {
        var currencies = CurrenciesBusinessLayer.GetAllCurrencies();
        var target = currencies.AsEnumerable()
            .Select(row => new
            {
                Id = row.Field<int>(0),
                Code = row.Field<string>(1)!,
                Name = row.Field<string>(2)!,
                Rate = row.Field<decimal>(3),
            }).ToList();
        return Ok(target);
    }

    [HttpGet("GetCurrencyById/{ID}")]
    public IActionResult GetCurrencyById(byte id)
    {
        if (id == 0)
        {
            return BadRequest();
        }

        var currency = CurrenciesBusinessLayer.FindCurrency(id);

        if (currency == null)
            return NotFound();

        return Ok(currency);
    }
}