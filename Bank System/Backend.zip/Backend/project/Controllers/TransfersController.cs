﻿using System.Data;
using System.Globalization;
using BusinessLayer;
using Microsoft.AspNetCore.Mvc;

namespace project.Controllers;

[Route("api/[controller]")]
[ApiController]
public class TransfersController : ControllerBase
{
    [HttpGet("GetTotalTransfers")]
    public IActionResult GetTotalTransfers()
    {
        var total = TransfersBusinessLayer.GetTotalTransfers();

        return Ok(new { Total = total });
    }

    [HttpGet("GetTransfersHistory")]
    public IActionResult GetTransfersHistory()
    {
        var transfers = TransfersBusinessLayer.GetAllTransfers();
        var target = transfers.AsEnumerable()
            .Select(row => new
            {
                TransferId = row.Field<int>(0),
                FromClient = row.IsNull("From") ? "-" : row.Field<string>(1),
                ToClient = row.IsNull("To") ? "-" : row.Field<string>(2),
                Amount = row.Field<decimal>(3),
                Date = row.Field<DateTime>(4).ToString(CultureInfo.InvariantCulture)
            }).ToList();
        return Ok(target);
    }
}